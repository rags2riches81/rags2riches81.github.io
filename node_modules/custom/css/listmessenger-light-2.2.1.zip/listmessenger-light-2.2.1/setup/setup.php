<?php
/*
	ListMessenger - Professional Mailing List Management
	Copyright 2009 Silentweb [http://www.silentweb.ca]. All Rights Reserved.

	Developed By: Matt Simpson <msimpson@listmessenger.com>

	For the most recent version, visit the ListMessenger website:
	[http://www.listmessenger.com]

	License Information is found in licence.html
	$Id: setup.php 481 2009-11-29 16:21:11Z matt.simpson $
*/

// The setup application is now in the index.
header("Location: ../setup.php");
exit;

?>