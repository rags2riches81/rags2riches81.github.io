
ListMessenger Light Readme File
Version:	2.2.1
Website:	http://www.listmessenger.com
Support:	http://forum.listmessenger.com
Author:		Matt Simpson <msimpson@listmessenger.com>
Tab Stop:	4 spaces
================================================================================

INSTALLATION)
	For information on installing ListMessenger, please read the install.txt
	file which outlines the installation procedure.

UPGRADING)
	For information on upgrading from a previous version of ListMessenger Light:
	- If you are upgrading from ListMessenger Light 2.x, please read the
	  upgrade_2.x.txt file.

	- If you are upgrading from any other version, please read the
	  upgrade_1.x.txt file.

TECHNICAL SUPPORT)
	ListMessenger Light technical support is available at lower priority from
	our public forums which can be accessed 24/7 by visiting:

	http://forum.listmessenger.com

	Please _do not_ e-mail me with technical support related issues.